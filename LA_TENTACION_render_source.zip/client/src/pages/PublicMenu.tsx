import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowRight, Check, ChevronDown, Clock3, MapPin, Minus, Phone, Plus, Search, ShoppingBag, Sparkles, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

const money = (value: number) => `RD$${value.toLocaleString("es-DO")}`;

type CartLine = { id: number; name: string; price: number; quantity: number; imageUrl?: string | null };

export default function PublicMenu() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("Todos");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [submitted, setSubmitted] = useState<{ number: string; url: string } | null>(null);
  const [customer, setCustomer] = useState({ name: "", phone: "", fulfillment: "delivery" as "delivery" | "pickup", address: "", notes: "" });
  const catalog = trpc.catalog.list.useQuery({ search: search || undefined });
  const settings = trpc.settings.get.useQuery();
  const createOrder = trpc.orders.create.useMutation();

  const products = catalog.data?.products ?? [];
  const categories = catalog.data?.categories ?? [];
  const filteredProducts = useMemo(() => activeCategory === "Todos" ? products : products.filter(product => categories.find(category => category.id === product.categoryId)?.name === activeCategory), [activeCategory, categories, products]);
  const cartCount = cart.reduce((total, line) => total + line.quantity, 0);
  const subtotal = cart.reduce((total, line) => total + line.price * line.quantity, 0);
  const deliveryFee = customer.fulfillment === "delivery" ? Number(settings.data?.deliveryFee ?? 100) : 0;
  const total = subtotal + deliveryFee;

  const addToCart = (product: (typeof products)[number]) => {
    setCart(current => {
      const existing = current.find(line => line.id === product.id);
      if (existing) return current.map(line => line.id === product.id ? { ...line, quantity: line.quantity + 1 } : line);
      return [...current, { id: product.id, name: product.name, price: product.price, quantity: 1, imageUrl: product.imageUrl }];
    });
    toast.success(`${product.name} añadido`, { duration: 1600 });
  };

  const updateQuantity = (id: number, delta: number) => {
    setCart(current => current.flatMap(line => line.id === id ? (line.quantity + delta <= 0 ? [] : [{ ...line, quantity: line.quantity + delta }]) : [line]));
  };

  const placeOrder = async () => {
    if (!customer.name.trim() || !customer.phone.trim()) return toast.error("Agrega tu nombre y teléfono para confirmar.");
    if (customer.fulfillment === "delivery" && !customer.address.trim()) return toast.error("Necesitamos tu dirección de delivery.");
    if (cart.length === 0) return toast.error("Tu carrito está vacío.");
    try {
      const result = await createOrder.mutateAsync({
        source: "online",
        customerName: customer.name,
        customerPhone: customer.phone,
        fulfillment: customer.fulfillment,
        address: customer.address || undefined,
        notes: customer.notes || undefined,
        discount: 0,
        deliveryFee,
        paymentMethod: "cash",
        paymentReceived: false,
        idempotencyKey: `web-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
        items: cart.map(line => ({ productId: line.id, quantity: line.quantity })),
      });
      const order = result.order;
      if (!order) throw new Error("No se pudo crear la orden");
      const lines = cart.map(line => `• ${line.quantity} × ${line.name}`).join("\n");
      const message = `Hola, quiero realizar un pedido en LA TENTACIÓN.\n\nNúmero de pedido: #${order.orderNumber}\n\nProductos:\n${lines}\n\nSubtotal: ${money(order.subtotal)}\nDelivery: ${money(order.deliveryFee)}\nTotal: ${money(order.total)}\n\nNombre: ${customer.name}\nTeléfono: ${customer.phone}\nModalidad: ${customer.fulfillment === "delivery" ? "Delivery" : "Recogida"}\nDirección: ${customer.address || "No aplica"}${customer.notes ? `\nObservaciones: ${customer.notes}` : ""}`;
      const phone = String(settings.data?.whatsapp ?? "18090000000").replace(/\D/g, "");
      const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
      setSubmitted({ number: order.orderNumber, url });
      setCart([]);
      setCheckoutOpen(false);
      toast.success("Pedido guardado. WhatsApp está listo.");
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "No se pudo guardar el pedido.");
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f0e9] text-[#171719]">
      <header className="sticky top-0 z-30 border-b border-[#ded7cc] bg-[#f4f0e9]/95 backdrop-blur">
        <div className="mx-auto flex h-[76px] max-w-[1380px] items-center justify-between px-5 lg:px-10">
          <a href="#inicio" className="flex items-center gap-3">
            <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-[#171719] text-[#fffaf4] shadow-card"><span className="font-display text-xl font-bold">LT</span><span className="absolute -right-1 -top-1 h-3 w-3 rotate-45 bg-[#e8342a]" /></div>
            <div><div className="font-display text-xl font-bold tracking-tight">LA TENTACIÓN</div><div className="font-mono text-[9px] tracking-[.22em] text-[#716c66]">EL SABOR QUE TE TIENTA</div></div>
          </a>
          <nav className="hidden items-center gap-7 text-sm font-semibold md:flex"><a href="#menu" className="text-[#716c66] hover:text-[#171719]">Menú</a><a href="#favoritos" className="text-[#716c66] hover:text-[#171719]">Favoritos</a><a href="#info" className="text-[#716c66] hover:text-[#171719]">Encuéntranos</a></nav>
          <div className="flex items-center gap-2"><Link href="/login"><Button variant="ghost" className="hidden text-sm font-semibold sm:inline-flex">Panel de operaciones</Button></Link><Button onClick={() => setCheckoutOpen(true)} className="relative rounded-full bg-[#e8342a] px-4 text-[#fffaf4] hover:bg-[#c92820]"><ShoppingBag size={17} /> <span className="hidden sm:inline">Mi pedido</span>{cartCount > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#171719] px-1 text-[10px] font-bold text-white">{cartCount}</span>}</Button></div>
        </div>
      </header>

      <main>
        <section id="inicio" className="relative overflow-hidden bg-[#171719] text-[#fffaf4]">
          <div className="absolute inset-0 opacity-[.08] paper-lines" />
          <div className="mx-auto grid max-w-[1380px] items-center gap-12 px-5 py-16 lg:grid-cols-[1.05fr_.95fr] lg:px-10 lg:py-24">
            <div className="relative z-10 max-w-2xl rise-in"><div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 px-3 py-1.5 text-xs font-semibold text-[#ffc8c4]"><Sparkles size={13} /> Hecho al momento · Sabor sin atajos</div><h1 className="font-display text-5xl font-bold leading-[.96] tracking-[-.055em] sm:text-7xl">El antojo<br /><span className="text-[#e8342a]">manda.</span></h1><p className="mt-6 max-w-lg text-base leading-7 text-white/65 sm:text-lg">Hamburguesas, yaroas y combos con actitud. Pide desde aquí y deja que la cocina haga lo suyo.</p><a href="#menu"><Button className="mt-8 h-12 rounded-full bg-[#e8342a] px-6 text-base font-bold text-white hover:bg-[#c92820]">Ver el menú <ArrowRight size={18} /></Button></a><div className="mt-10 flex flex-wrap gap-6 text-sm text-white/55"><span className="flex items-center gap-2"><Clock3 size={15} className="text-[#e8342a]" /> {settings.data?.openingHours ?? "Abierto hoy · 11 AM – 11 PM"}</span><span className="flex items-center gap-2"><MapPin size={15} className="text-[#e8342a]" /> Santo Domingo</span></div></div>
            <div className="relative min-h-[360px] lg:min-h-[470px]"><div className="absolute right-0 top-3 h-[350px] w-[350px] overflow-hidden rounded-[2rem] border-[10px] border-[#2a292c] rotate-3 shadow-2xl lg:h-[470px] lg:w-[470px]"><img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1100&q=90" alt="Hamburguesa de LA TENTACIÓN" className="h-full w-full object-cover" /></div><div className="absolute bottom-7 left-0 z-10 rounded-2xl bg-[#e8342a] p-4 shadow-xl lg:left-4"><div className="font-mono text-[10px] uppercase tracking-[.2em] text-white/70">La recomendación</div><div className="mt-1 font-display text-xl font-bold">La Tentación Burger</div><div className="mt-1 font-mono text-sm">RD$350</div></div></div>
          </div>
        </section>

        <section id="menu" className="mx-auto max-w-[1380px] px-5 py-14 lg:px-10 lg:py-20"><div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end"><div><div className="font-mono text-[11px] font-semibold uppercase tracking-[.2em] text-[#e8342a]">/ Menú de hoy</div><h2 className="mt-2 font-display text-4xl font-bold tracking-[-.04em] sm:text-5xl">Lo que sale de cocina.</h2></div><div className="relative w-full sm:w-[290px]"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#716c66]" size={17} /><Input value={search} onChange={event => setSearch(event.target.value)} placeholder="Buscar en el menú" className="h-11 rounded-full border-[#ded7cc] bg-[#fffdf9] pl-10" /></div></div>
          <div className="mt-8 flex gap-2 overflow-x-auto pb-2"><button onClick={() => setActiveCategory("Todos")} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold transition ${activeCategory === "Todos" ? "bg-[#171719] text-white" : "bg-[#e6e0d7] text-[#716c66] hover:bg-[#d9d2c8]"}`}>Todos</button>{categories.map(category => <button key={category.id} onClick={() => setActiveCategory(category.name)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold transition ${activeCategory === category.name ? "bg-[#171719] text-white" : "bg-[#e6e0d7] text-[#716c66] hover:bg-[#d9d2c8]"}`}>{category.name}</button>)}</div>
          <div className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{filteredProducts.map((product, index) => <article key={product.id} className="group overflow-hidden rounded-2xl border border-[#ded7cc] bg-[#fffdf9] shadow-card transition hover:-translate-y-1 hover:shadow-soft" style={{ animationDelay: `${index * 50}ms` }}><div className="relative aspect-[1.18] overflow-hidden bg-[#e6e0d7]"><img src={product.imageUrl ?? "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85"} alt={product.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />{product.isFeatured && <span className="absolute left-3 top-3 rounded-full bg-[#e8342a] px-3 py-1 text-[10px] font-bold uppercase tracking-[.15em] text-white">Favorito</span>}<button onClick={() => addToCart(product)} className="absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full bg-[#171719] text-white opacity-0 transition group-hover:opacity-100 hover:bg-[#e8342a]"><Plus size={19} /></button></div><div className="p-5"><div className="flex items-start justify-between gap-4"><div><h3 className="font-display text-xl font-bold">{product.name}</h3><p className="mt-2 line-clamp-2 text-sm leading-5 text-[#716c66]">{product.description}</p></div><div className="font-mono text-sm font-semibold text-[#e8342a]">{money(product.price)}</div></div><Button onClick={() => addToCart(product)} variant="outline" className="mt-5 w-full rounded-xl border-[#ded7cc] font-bold hover:border-[#e8342a] hover:text-[#e8342a]">Añadir al pedido <Plus size={16} /></Button></div></article>)}</div>
          {filteredProducts.length === 0 && <div className="rounded-2xl border border-dashed border-[#cfc6ba] p-14 text-center text-[#716c66]">No encontramos ese antojo. Prueba otra búsqueda.</div>}
        </section>

        <section id="favoritos" className="border-y border-[#ded7cc] bg-[#e8e2da]"><div className="mx-auto grid max-w-[1380px] gap-8 px-5 py-12 lg:grid-cols-[.9fr_1.1fr] lg:px-10 lg:py-16"><div><div className="font-mono text-[11px] uppercase tracking-[.2em] text-[#e8342a]">/ Para compartir</div><h2 className="mt-3 font-display text-4xl font-bold tracking-[-.04em]">La mesa pide<br /><span className="text-[#e8342a]">algo grande.</span></h2><p className="mt-4 max-w-md text-[#716c66]">Arma tu pedido para la oficina, el coro o esa noche en la que nadie quiere cocinar.</p></div><div className="grid gap-3 sm:grid-cols-3">{products.filter(product => product.isFeatured).slice(0, 3).map(product => <button key={product.id} onClick={() => addToCart(product)} className="group overflow-hidden rounded-2xl bg-[#171719] text-left text-white"><div className="aspect-square overflow-hidden"><img src={product.imageUrl ?? ""} alt="" className="h-full w-full object-cover opacity-80 transition group-hover:scale-105 group-hover:opacity-100" /></div><div className="p-3"><div className="font-display font-bold leading-tight">{product.name}</div><div className="mt-1 font-mono text-xs text-[#ffc8c4]">{money(product.price)}</div></div></button>)}</div></div></section>
        <footer id="info" className="bg-[#171719] px-5 py-10 text-white lg:px-10"><div className="mx-auto flex max-w-[1380px] flex-col justify-between gap-6 sm:flex-row sm:items-end"><div><div className="font-display text-2xl font-bold">LA TENTACIÓN<span className="text-[#e8342a]">.</span></div><p className="mt-2 max-w-sm text-sm text-white/50">{settings.data?.tagline ?? "EL SABOR QUE TE TIENTA"}. Pedidos directos, cocina honesta.</p></div><div className="text-sm text-white/55"><div className="flex items-center gap-2"><MapPin size={15} className="text-[#e8342a]" /> {settings.data?.address ?? "Santo Domingo, República Dominicana"}</div><div className="mt-2 flex items-center gap-2"><Phone size={15} className="text-[#e8342a]" /> +1 (809) 000-0000</div></div></div></footer>
      </main>

      {cart.length > 0 && !checkoutOpen && <button onClick={() => setCheckoutOpen(true)} className="fixed bottom-5 right-5 z-20 flex items-center gap-3 rounded-full bg-[#e8342a] px-5 py-3 font-bold text-white shadow-2xl hover:bg-[#c92820]"><ShoppingBag size={18} /> Ver pedido · {money(total)} <ChevronDown size={16} className="rotate-180" /></button>}
      {checkoutOpen && <div className="fixed inset-0 z-50 flex justify-end bg-[#171719]/40 backdrop-blur-sm"><aside className="flex h-full w-full max-w-[470px] flex-col bg-[#fffdf9] shadow-2xl"><div className="flex items-center justify-between border-b border-[#ded7cc] p-5"><div><div className="font-mono text-[10px] uppercase tracking-[.2em] text-[#e8342a]">/ Tu comanda</div><h2 className="mt-1 font-display text-2xl font-bold">Mi pedido <span className="font-mono text-sm text-[#716c66]">({cartCount})</span></h2></div><button onClick={() => setCheckoutOpen(false)} className="rounded-full p-2 text-[#716c66] hover:bg-[#e6e0d7]"><X size={20} /></button></div>{submitted ? <div className="flex flex-1 flex-col items-center justify-center px-7 text-center"><div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#e6f5e8] text-[#198754]"><Check size={30} /></div><h3 className="mt-5 font-display text-3xl font-bold">Pedido guardado.</h3><p className="mt-3 text-[#716c66]">Tu número es <span className="font-mono font-bold text-[#171719]">{submitted.number}</span>. Ábrelo en WhatsApp para enviarlo a cocina.</p><a href={submitted.url} target="_blank" rel="noreferrer" className="mt-7 inline-flex h-11 items-center gap-2 rounded-full bg-[#25D366] px-5 font-bold text-white">Abrir WhatsApp <ArrowRight size={17} /></a><button onClick={() => setSubmitted(null)} className="mt-4 text-sm font-semibold text-[#716c66] underline">Hacer otro pedido</button></div> : <><div className="flex-1 overflow-y-auto p-5">{cart.length === 0 ? <div className="py-10 text-center text-[#716c66]">Tu pedido está vacío.</div> : <div className="space-y-3">{cart.map(line => <div key={line.id} className="flex gap-3 rounded-xl border border-[#ded7cc] p-3"><img src={line.imageUrl ?? ""} alt="" className="h-16 w-16 rounded-lg object-cover" /><div className="min-w-0 flex-1"><div className="truncate font-display font-bold">{line.name}</div><div className="mt-1 font-mono text-xs text-[#e8342a]">{money(line.price)}</div><div className="mt-2 flex items-center gap-2"><button onClick={() => updateQuantity(line.id, -1)} className="flex h-6 w-6 items-center justify-center rounded-full bg-[#e6e0d7]"><Minus size={12} /></button><span className="font-mono text-xs font-bold">{line.quantity}</span><button onClick={() => updateQuantity(line.id, 1)} className="flex h-6 w-6 items-center justify-center rounded-full bg-[#171719] text-white"><Plus size={12} /></button></div></div><div className="font-mono text-sm font-bold">{money(line.price * line.quantity)}</div></div>)}</div>}<div className="my-6 h-px bg-[#ded7cc]" /><div className="grid grid-cols-2 gap-3"><Input value={customer.name} onChange={event => setCustomer({ ...customer, name: event.target.value })} placeholder="Tu nombre" /><Input value={customer.phone} onChange={event => setCustomer({ ...customer, phone: event.target.value })} placeholder="Teléfono" /></div><div className="mt-3 grid grid-cols-2 gap-2"><button onClick={() => setCustomer({ ...customer, fulfillment: "delivery" })} className={`rounded-xl border p-3 text-left text-sm font-bold ${customer.fulfillment === "delivery" ? "border-[#e8342a] bg-[#fff1ef] text-[#e8342a]" : "border-[#ded7cc]"}`}>Delivery <span className="block text-xs font-normal text-[#716c66]">+{money(deliveryFee)}</span></button><button onClick={() => setCustomer({ ...customer, fulfillment: "pickup", address: "" })} className={`rounded-xl border p-3 text-left text-sm font-bold ${customer.fulfillment === "pickup" ? "border-[#e8342a] bg-[#fff1ef] text-[#e8342a]" : "border-[#ded7cc]"}`}>Recogida <span className="block text-xs font-normal text-[#716c66]">Sin delivery</span></button></div>{customer.fulfillment === "delivery" && <Input value={customer.address} onChange={event => setCustomer({ ...customer, address: event.target.value })} placeholder="Dirección de entrega" className="mt-3" />}<Textarea value={customer.notes} onChange={event => setCustomer({ ...customer, notes: event.target.value })} placeholder="Observaciones (opcional)" className="mt-3 min-h-20" /></div><div className="border-t border-[#ded7cc] bg-[#f4f0e9] p-5"><div className="flex items-center justify-between text-sm text-[#716c66]"><span>Subtotal</span><span className="font-mono">{money(subtotal)}</span></div><div className="mt-2 flex items-center justify-between text-sm text-[#716c66]"><span>Delivery</span><span className="font-mono">{money(deliveryFee)}</span></div><div className="mt-4 flex items-center justify-between"><span className="font-display text-xl font-bold">Total</span><span className="font-mono text-xl font-bold text-[#e8342a]">{money(total)}</span></div><Button onClick={placeOrder} disabled={createOrder.isPending || cart.length === 0} className="mt-5 h-12 w-full rounded-xl bg-[#e8342a] text-base font-bold text-white hover:bg-[#c92820]">{createOrder.isPending ? "Guardando pedido..." : "Confirmar y abrir WhatsApp"} <ArrowRight size={17} /></Button><p className="mt-3 text-center text-[11px] text-[#716c66]">Primero guardamos tu pedido; luego lo enviamos a WhatsApp.</p></div></>}</aside></div>}
    </div>
  );
}
