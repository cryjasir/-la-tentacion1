import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ArrowRight, Eye, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

export default function Login() {
  const [, setLocation] = useLocation();
  const me = trpc.auth.me.useQuery();
  const login = trpc.auth.login.useMutation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => { if (me.data) setLocation("/admin"); }, [me.data, setLocation]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      await login.mutateAsync({ username, password });
      await me.refetch();
      toast.success("Sesión iniciada");
      setLocation("/admin");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "No se pudo iniciar sesión.");
    }
  };

  return <div className="min-h-screen bg-[#171719] text-[#fffaf4]"><div className="mx-auto grid min-h-screen max-w-[1380px] lg:grid-cols-[1.05fr_.95fr]"><section className="relative hidden overflow-hidden p-10 lg:flex lg:flex-col lg:justify-between"><div className="absolute inset-0 paper-lines opacity-[.1]" /><div className="relative"><Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-white/65 hover:text-white"><ArrowLeft size={16} /> Volver al menú</Link><div className="mt-28 max-w-xl"><div className="font-mono text-[11px] uppercase tracking-[.22em] text-[#ff9189]">/ Centro de mando</div><h1 className="mt-4 font-display text-7xl font-bold leading-[.92] tracking-[-.06em]">Lo que sale hoy,<br /><span className="text-[#e8342a]">bajo control.</span></h1><p className="mt-7 max-w-md text-lg leading-8 text-white/55">Pedidos, ventas y cocina en un solo lugar. Diseñado para moverse al ritmo de tu negocio.</p></div></div><div className="relative flex items-center justify-between border-t border-white/10 pt-5 text-sm text-white/40"><span>LA TENTACIÓN · OPERACIONES</span><span className="font-mono text-[11px]">v1.0 / RD</span></div></section><section className="flex items-center justify-center bg-[#f4f0e9] px-5 py-12 text-[#171719] sm:px-10"><div className="w-full max-w-md"><Link href="/" className="mb-12 inline-flex items-center gap-2 text-sm font-semibold text-[#716c66] lg:hidden"><ArrowLeft size={16} /> Volver al menú</Link><div className="mb-10 flex items-center gap-3"><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#171719] font-display text-xl font-bold text-white">LT</div><div><div className="font-display text-xl font-bold">LA TENTACIÓN</div><div className="font-mono text-[9px] tracking-[.2em] text-[#716c66]">PANEL PRIVADO</div></div></div><div className="mb-8"><h2 className="font-display text-4xl font-bold tracking-[-.05em]">Entrar a operaciones.</h2><p className="mt-3 leading-6 text-[#716c66]">Usa tus credenciales para administrar el restaurante.</p></div><form onSubmit={submit} className="space-y-5"><div><label className="mb-2 block text-sm font-bold">Usuario o código</label><Input autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} placeholder="Ej. test1" className="h-12 rounded-xl border-[#cfc6ba] bg-white" /></div><div><label className="mb-2 block text-sm font-bold">Contraseña</label><div className="relative"><Input autoComplete="current-password" type={showPassword ? "text" : "password"} value={password} onChange={event => setPassword(event.target.value)} placeholder="••••••••" className="h-12 rounded-xl border-[#cfc6ba] bg-white pr-11" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#716c66]">{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></div><Button disabled={login.isPending} type="submit" className="h-12 w-full rounded-xl bg-[#e8342a] text-base font-bold text-white hover:bg-[#c92820]">{login.isPending ? "Verificando..." : "Entrar al panel"} <ArrowRight size={17} /></Button></form><div className="mt-8 grid gap-3 rounded-2xl border border-[#ded7cc] bg-[#fffdf9] p-4 text-sm text-[#716c66]"><div className="flex gap-3"><ShieldCheck size={18} className="shrink-0 text-[#e8342a]" /><div><div className="font-bold text-[#171719]">Sesión protegida</div><div className="mt-1">Las contraseñas se validan con hash y la sesión usa una cookie segura.</div></div></div><div className="flex gap-3"><LockKeyhole size={18} className="shrink-0 text-[#e8342a]" /><div><div className="font-bold text-[#171719]">Acceso inicial</div><div className="mt-1">Propietario: <span className="font-mono">test1</span> · contraseña provisional configurada.</div></div></div></div></div></section></div></div>;
}
