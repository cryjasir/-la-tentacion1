import { COOKIE_NAME } from "@shared/const";
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { randomBytes, timingSafeEqual, scryptSync } from "node:crypto";
import { nanoid } from "nanoid";
import { z } from "zod";
import { categories, expenses, inventoryItems, orderItems, orders, products, settings, users } from "../drizzle/schema";
import * as db from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { ENV } from "./_core/env";
import { sdk } from "./_core/sdk";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";

const money = z.number().int().min(0).max(10_000_000);
const orderStatus = z.enum(["pending", "confirmed", "preparing", "ready", "out_for_delivery", "delivered", "cancelled"]);

function normalizeUsername(value: string) {
  return value.trim().toLowerCase().replace(/\s+/g, "");
}

function verifyPassword(password: string, encoded: string) {
  const [saltHex, hashHex] = encoded.split(":");
  if (!saltHex || !hashHex) return false;
  const derived = scryptSync(password, Buffer.from(saltHex, "hex"), 64);
  const expected = Buffer.from(hashHex, "hex");
  return derived.length === expected.length && timingSafeEqual(derived, expected);
}

function hashPassword(password: string) {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64);
  return `${salt.toString("hex")}:${hash.toString("hex")}`;
}

function safeUser(user: typeof users.$inferSelect) {
  return { id: user.id, name: user.name, username: user.username, role: user.role, email: user.email, employeeCode: user.employeeCode };
}

async function requireDatabase() {
  const database = await db.getDb();
  if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "La base de datos no está disponible." });
  return database;
}

function requireStaff(user: typeof users.$inferSelect) {
  if (!["admin", "employee", "kitchen"].includes(user.role)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "No tienes permisos de personal." });
  }
}

function requireAdmin(user: typeof users.$inferSelect) {
  if (user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Solo el propietario puede realizar esta acción." });
  }
}

export const appRouter = router({
  system: router({
    health: publicProcedure.query(() => ({ ok: true, service: "la-tentacion" })),
  }),

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user ? safeUser(opts.ctx.user) : null),
    login: publicProcedure.input(z.object({ username: z.string().min(1), password: z.string().min(1) })).mutation(async ({ input, ctx }) => {
      await db.ensureSeedData();
      const user = await db.getUserByIdentifier(normalizeUsername(input.username));
      if (!user?.passwordHash || !user.isActive || !verifyPassword(input.password, user.passwordHash)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Usuario o contraseña incorrectos." });
      }
      const token = await sdk.signSession({ openId: user.openId, appId: ENV.appId, name: user.name ?? user.username ?? "" });
      ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: 1000 * 60 * 60 * 12 });
      const database = await requireDatabase();
      await database.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));
      await db.addAudit(user.id, "login", "auth", user.id, "Inicio de sesión local");
      return safeUser(user);
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      if (ctx.user) await db.addAudit(ctx.user.id, "logout", "auth", ctx.user.id);
      ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  employees: router({
    list: adminProcedure.query(async () => {
      const database = await requireDatabase();
      return database.select({ id: users.id, name: users.name, username: users.username, employeeCode: users.employeeCode, role: users.role, isActive: users.isActive, lastSignedIn: users.lastSignedIn }).from(users).where(inArray(users.role, ["employee", "kitchen"])).orderBy(desc(users.createdAt));
    }),
    create: adminProcedure.input(z.object({ name: z.string().min(2).max(120), username: z.string().min(3).max(64).optional(), employeeCode: z.string().min(4).max(32).optional(), password: z.string().min(6).max(120).optional(), role: z.enum(["employee", "kitchen"]) })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      const employeeCode = input.employeeCode?.trim().toUpperCase() || `EMP-${nanoid(6).toUpperCase()}`;
      const result = await database.insert(users).values({ openId: `local-${nanoid(16)}`, name: input.name, username: input.username ? normalizeUsername(input.username) : null, employeeCode, passwordHash: input.password ? hashPassword(input.password) : null, role: input.role, loginMethod: "local", isActive: true });
      await db.addAudit(ctx.user.id, "create", "employee", Number(result[0].insertId), input.name);
      return { id: Number(result[0].insertId), employeeCode };
    }),
    deactivate: adminProcedure.input(z.object({ id: z.number().int().positive(), isActive: z.boolean() })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      await database.update(users).set({ isActive: input.isActive }).where(and(eq(users.id, input.id), inArray(users.role, ["employee", "kitchen"])));
      await db.addAudit(ctx.user.id, input.isActive ? "activate" : "deactivate", "employee", input.id);
      return { success: true } as const;
    }),
    resetCode: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      const employeeCode = `EMP-${nanoid(6).toUpperCase()}`;
      await database.update(users).set({ employeeCode }).where(and(eq(users.id, input.id), inArray(users.role, ["employee", "kitchen"])));
      await db.addAudit(ctx.user.id, "reset_code", "employee", input.id);
      return { employeeCode };
    }),
  }),

  catalog: router({
    list: publicProcedure.input(z.object({ search: z.string().optional() }).optional()).query(({ input }) => db.listCatalog(input?.search ?? "")),
    adminList: protectedProcedure.input(z.object({ search: z.string().optional() }).optional()).query(({ input, ctx }) => { requireStaff(ctx.user); return db.listAdminProducts(input?.search ?? ""); }),
    create: adminProcedure.input(z.object({ categoryId: z.number().int().positive(), name: z.string().min(2), description: z.string().optional(), price: money, cost: money.default(0), imageUrl: z.string().url().optional(), isFeatured: z.boolean().default(false) })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      const result = await database.insert(products).values({ ...input, description: input.description ?? null, imageUrl: input.imageUrl ?? null });
      await db.addAudit(ctx.user.id, "create", "product", Number(result[0].insertId), input.name);
      return { id: Number(result[0].insertId) };
    }),
    update: adminProcedure.input(z.object({ id: z.number().int().positive(), name: z.string().min(2).optional(), description: z.string().optional(), price: money.optional(), cost: money.optional(), categoryId: z.number().int().positive().optional(), imageUrl: z.string().url().nullable().optional(), isAvailable: z.boolean().optional(), isFeatured: z.boolean().optional() })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      const { id, ...changes } = input;
      await database.update(products).set(changes).where(eq(products.id, id));
      await db.addAudit(ctx.user.id, "update", "product", id, JSON.stringify(changes));
      return { success: true } as const;
    }),
    toggleAvailability: adminProcedure.input(z.object({ id: z.number().int().positive(), isAvailable: z.boolean() })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      await database.update(products).set({ isAvailable: input.isAvailable }).where(eq(products.id, input.id));
      await db.addAudit(ctx.user.id, "availability", "product", input.id, String(input.isAvailable));
      return { success: true } as const;
    }),
    categories: protectedProcedure.query(async ({ ctx }) => {
      requireStaff(ctx.user);
      const database = await requireDatabase();
      await db.ensureSeedData();
      return database.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.sortOrder));
    }),
  }),

  orders: router({
    list: protectedProcedure.input(z.object({ limit: z.number().int().min(1).max(100).default(50) }).optional()).query(({ input, ctx }) => { requireStaff(ctx.user); return db.listOrders(input?.limit ?? 50); }),
    get: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input, ctx }) => { requireStaff(ctx.user); return db.getOrderDetails(input.id); }),
    create: publicProcedure.input(z.object({
      source: z.enum(["online", "manual"]).default("online"),
      customerName: z.string().min(2).max(120),
      customerPhone: z.string().min(7).max(40),
      fulfillment: z.enum(["delivery", "pickup"]),
      address: z.string().max(500).optional(),
      notes: z.string().max(500).optional(),
      discount: money.default(0),
      deliveryFee: money.default(0),
      paymentMethod: z.enum(["cash", "transfer", "other"]).default("cash"),
      paymentReceived: z.boolean().default(false),
      idempotencyKey: z.string().min(8).max(100),
      items: z.array(z.object({ productId: z.number().int().positive(), quantity: z.number().int().min(1).max(50) })).min(1),
    })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      await db.ensureSeedData();
      if (input.source === "manual") {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Debes iniciar sesión para registrar ventas." });
        requireStaff(ctx.user);
      }
      if (input.fulfillment === "delivery" && !input.address?.trim()) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "La dirección es obligatoria para delivery." });
      }
      const productIds = input.items.map(item => item.productId);
      const selectedProducts = await database.select().from(products).where(and(inArray(products.id, productIds), eq(products.isActive, true), eq(products.isAvailable, true)));
      if (selectedProducts.length !== productIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Uno de los productos ya no está disponible." });
      const byId = new Map(selectedProducts.map(product => [product.id, product]));
      const lineItems = input.items.map(item => {
        const product = byId.get(item.productId)!;
        return { productId: product.id, productName: product.name, unitPrice: product.price, quantity: item.quantity, lineTotal: product.price * item.quantity };
      });
      const subtotal = lineItems.reduce((sum, item) => sum + item.lineTotal, 0);
      const configuredDelivery = await database.select({ value: settings.value }).from(settings).where(eq(settings.key, "deliveryFee")).limit(1);
      const serverDeliveryFee = Number(configuredDelivery[0]?.value ?? 100);
      const effectiveDiscount = input.source === "manual" ? input.discount : 0;
      const effectiveDelivery = input.fulfillment === "delivery" ? serverDeliveryFee : 0;
      const total = Math.max(0, subtotal - effectiveDiscount + effectiveDelivery);
      const orderNumber = `LT-${new Date().getFullYear()}-${nanoid(8).toUpperCase()}`;
      try {
        const created = await database.transaction(async tx => {
          const result = await tx.insert(orders).values({
            orderNumber,
            source: input.source,
            status: input.source === "manual" ? "confirmed" : "pending",
            customerName: input.customerName,
            customerPhone: input.customerPhone,
            fulfillment: input.fulfillment,
            address: input.address ?? null,
            notes: input.notes ?? null,
            subtotal,
            discount: effectiveDiscount,
            deliveryFee: effectiveDelivery,
            total,
            paymentMethod: input.paymentMethod,
            paymentReceived: input.source === "manual" ? input.paymentReceived : false,
            createdBy: ctx.user?.id ?? null,
            idempotencyKey: input.idempotencyKey,
          });
          const orderId = Number(result[0].insertId);
          await tx.insert(orderItems).values(lineItems.map(item => ({ ...item, orderId })));
          return { orderId, orderNumber };
        });
        await db.addAudit(ctx.user?.id ?? null, "create", "order", created.orderId, `${created.orderNumber} · ${input.source}`);
        const order = await db.getOrderDetails(created.orderId);
        return { order, duplicate: false };
      } catch (error) {
        const existing = await database.select().from(orders).where(eq(orders.idempotencyKey, input.idempotencyKey)).limit(1);
        if (existing[0]) return { order: existing[0], duplicate: true };
        throw error;
      }
    }),
    updateStatus: protectedProcedure.input(z.object({ id: z.number().int().positive(), status: orderStatus })).mutation(async ({ input, ctx }) => {
      requireStaff(ctx.user);
      const database = await requireDatabase();
      await database.update(orders).set({ status: input.status }).where(eq(orders.id, input.id));
      await db.addAudit(ctx.user.id, "status", "order", input.id, input.status);
      return { success: true } as const;
    }),
  }),

  dashboard: router({
    summary: protectedProcedure.query(({ ctx }) => { requireStaff(ctx.user); return db.dashboardSummary(); }),
  }),

  settings: router({
    get: publicProcedure.query(async () => {
      const database = await requireDatabase();
      await db.ensureSeedData();
      const rows = await database.select().from(settings);
      return Object.fromEntries(rows.map(row => [row.key, row.value ?? ""]));
    }),
    update: adminProcedure.input(z.record(z.string().min(1), z.string().max(500))).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      for (const [key, value] of Object.entries(input)) {
        await database.insert(settings).values({ key, value }).onDuplicateKeyUpdate({ set: { value } });
      }
      await db.addAudit(ctx.user.id, "update", "settings", null, JSON.stringify(Object.keys(input)));
      return { success: true } as const;
    }),
  }),

  inventory: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      requireStaff(ctx.user);
      const database = await requireDatabase();
      await db.ensureSeedData();
      return database.select().from(inventoryItems).where(eq(inventoryItems.isActive, true)).orderBy(asc(inventoryItems.name));
    }),
  }),

  finance: router({
    expenses: protectedProcedure.query(async ({ ctx }) => {
      requireAdmin(ctx.user);
      const database = await requireDatabase();
      return database.select().from(expenses).orderBy(desc(expenses.expenseDate)).limit(100);
    }),
    addExpense: adminProcedure.input(z.object({ category: z.enum(["ingredients", "delivery", "electricity", "water", "salary", "other"]), description: z.string().min(2), amount: money })).mutation(async ({ input, ctx }) => {
      const database = await requireDatabase();
      await database.insert(expenses).values({ ...input, createdBy: ctx.user.id });
      await db.addAudit(ctx.user.id, "create", "expense", null, input.description);
      return { success: true } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
