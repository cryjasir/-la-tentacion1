import { and, asc, desc, eq, gte, inArray, like, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  auditLogs,
  categories,
  expenses,
  inventoryItems,
  InsertUser,
  orderItems,
  orders,
  products,
  settings,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

const categorySeed = [
  ["Hamburguesas", "hamburguesas"],
  ["Yaroas", "yaroas"],
  ["Salchipapas", "salchipapas"],
  ["Hot Dogs", "hot-dogs"],
  ["Pizzas", "pizzas"],
  ["Pollo", "pollo"],
  ["Picaderas", "picaderas"],
  ["Bebidas", "bebidas"],
  ["Combos", "combos"],
  ["Especiales", "especiales"],
] as const;

const productSeed = [
  { category: "hamburguesas", name: "La Tentación Burger", description: "Carne artesanal, queso cheddar, bacon y salsa de la casa.", price: 350, cost: 150, imageUrl: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=85", featured: true },
  { category: "yaroas", name: "Yaroa Suprema", description: "Papas crujientes, pollo, queso fundido y salsas de la casa.", price: 350, cost: 140, imageUrl: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85", featured: true },
  { category: "salchipapas", name: "Salchipapa Fuego", description: "Papas, salchicha ahumada, queso y toque picante.", price: 280, cost: 110, imageUrl: "https://images.unsplash.com/photo-1623238913973-21e45cced554?auto=format&fit=crop&w=900&q=85", featured: false },
  { category: "hot-dogs", name: "Hot Dog Callejero", description: "Pan brioche, salchicha premium, crispy onions y mostaza.", price: 240, cost: 90, imageUrl: "https://images.unsplash.com/photo-1612392062631-94dd858cba88?auto=format&fit=crop&w=900&q=85", featured: false },
  { category: "pizzas", name: "Pizza Pepperoni", description: "Masa del día, mozzarella y pepperoni con borde dorado.", price: 650, cost: 260, imageUrl: "https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=900&q=85", featured: true },
  { category: "pollo", name: "Alitas BBQ", description: "Alitas doradas bañadas en BBQ ahumada y ajonjolí.", price: 420, cost: 190, imageUrl: "https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format&fit=crop&w=900&q=85", featured: false },
  { category: "picaderas", name: "Picadera Tentación", description: "Papas, alitas, deditos de queso y salsas para compartir.", price: 780, cost: 330, imageUrl: "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=900&q=85", featured: true },
  { category: "bebidas", name: "Refresco Frío", description: "Lata bien fría para completar tu orden.", price: 100, cost: 40, imageUrl: "https://images.unsplash.com/photo-1629203849820-fdd70d3e6cda?auto=format&fit=crop&w=900&q=85", featured: false },
  { category: "combos", name: "Combo Tentación", description: "Burger, papas y refresco. El clásico que nunca falla.", price: 520, cost: 225, imageUrl: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=900&q=85", featured: true },
];

const inventorySeed = [
  ["Pan brioche", "unidades", 84, 20, 35],
  ["Carne de hamburguesa", "unidades", 68, 15, 90],
  ["Queso cheddar", "porciones", 120, 25, 18],
  ["Papas", "libras", 42, 10, 42],
  ["Aceite", "litros", 18, 5, 160],
  ["Refrescos", "unidades", 55, 12, 35],
] as const;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  (['name', 'email', 'loginMethod', 'role', 'username', 'passwordHash', 'employeeCode', 'isActive', 'lastSignedIn'] as const).forEach(field => {
    if (user[field] !== undefined) {
      values[field] = user[field] as never;
      updateSet[field] = user[field];
    }
  });
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return result[0];
}

export async function getUserByIdentifier(identifier: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(sql`${users.username} = ${identifier} OR ${users.employeeCode} = ${identifier}`).limit(1);
  return result[0];
}

export async function ensureSeedData() {
  const db = await getDb();
  if (!db) return;
  const existingOwner = await db.select({ id: users.id }).from(users).where(eq(users.username, "test1")).limit(1);
  if (existingOwner.length === 0) {
    await db.insert(users).values({
      openId: "local-owner-test1",
      name: "Propietario",
      email: null,
      loginMethod: "local",
      role: "admin",
      username: "test1",
      // scrypt hash of the provisional password "test"; the plaintext is never stored.
      passwordHash: "8aa2fc683fb7ad3ddce4649452123083:017bfb825d3dab9838b6eed630ddfd62d996314b5b33975e1d661c1521057f830e4ea0244b2268be1df63bdc5b56a6a4a4f45a57f617b756c253c787556df49e",
      isActive: true,
    });
  }

  const existingCategories = await db.select({ id: categories.id }).from(categories).limit(1);
  if (existingCategories.length === 0) {
    await db.insert(categories).values(categorySeed.map(([name, slug], index) => ({ name, slug, sortOrder: index })));
  }

  const existingProductNames = await db.select({ name: products.name }).from(products);
  const existingProductNameSet = new Set(existingProductNames.map(product => product.name));
  const missingProducts = productSeed.filter(item => !existingProductNameSet.has(item.name));
  if (missingProducts.length > 0) {
    const cats = await db.select().from(categories);
    const bySlug = new Map(cats.map(category => [category.slug, category.id]));
    await db.insert(products).values(missingProducts.map(item => ({
      categoryId: bySlug.get(item.category) ?? cats[0].id,
      name: item.name,
      description: item.description,
      price: item.price,
      cost: item.cost,
      imageUrl: item.imageUrl,
      isFeatured: item.featured,
      isAvailable: true,
      isActive: true,
    })));
  }

  const existingInventory = await db.select({ id: inventoryItems.id }).from(inventoryItems).limit(1);
  if (existingInventory.length === 0) {
    await db.insert(inventoryItems).values(inventorySeed.map(([name, unit, quantity, minQuantity, costPerUnit]) => ({ name, unit, quantity, minQuantity, costPerUnit })));
  }

  const defaultSettings = {
    businessName: "LA TENTACIÓN",
    tagline: "EL SABOR QUE TE TIENTA",
    whatsapp: "18090000000",
    address: "Santo Domingo, República Dominicana",
    deliveryFee: "100",
    openingHours: "Lun–Dom · 11:00 AM – 11:00 PM",
  };
  for (const [key, value] of Object.entries(defaultSettings)) {
    await db.insert(settings).values({ key, value }).onDuplicateKeyUpdate({ set: { value } });
  }
}

export async function listCatalog(search = "") {
  const db = await getDb();
  if (!db) return { categories: [], products: [] };
  await ensureSeedData();
  const allCategories = await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.sortOrder));
  const filters = [eq(products.isActive, true), eq(products.isAvailable, true)];
  if (search.trim()) filters.push(like(products.name, `%${search.trim()}%`));
  const allProducts = await db.select().from(products).where(and(...filters)).orderBy(desc(products.isFeatured), asc(products.name));
  const uniqueProducts = Array.from(new Map(allProducts.map(product => [product.name, product])).values());
  return { categories: allCategories, products: uniqueProducts };
}

export async function listAdminProducts(search = "") {
  const db = await getDb();
  if (!db) return [];
  await ensureSeedData();
  const filters = [eq(products.isActive, true)];
  if (search.trim()) filters.push(like(products.name, `%${search.trim()}%`));
  const rows = await db.select({ product: products, categoryName: categories.name }).from(products).leftJoin(categories, eq(products.categoryId, categories.id)).where(and(...filters)).orderBy(desc(products.isFeatured), asc(products.name));
  return Array.from(new Map(rows.map(row => [row.product.name, row])).values());
}

export async function listOrders(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit);
}

export async function getOrderDetails(orderId: number) {
  const db = await getDb();
  if (!db) return null;
  const order = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order[0]) return null;
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  return { ...order[0], items };
}

export async function dashboardSummary() {
  const db = await getDb();
  if (!db) return { today: 0, week: 0, month: 0, orders: 0, pending: 0, preparing: 0, delivered: 0, expenses: 0, productLeaders: [], recent: [] };
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startWeek = new Date(startToday); startWeek.setDate(startToday.getDate() - ((startToday.getDay() + 6) % 7));
  const startMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const completed = inArray(orders.status, ["confirmed", "preparing", "ready", "out_for_delivery", "delivered"]);
  const [today, week, month, counts, recent, leaders, expenseSum] = await Promise.all([
    db.select({ total: sql<number>`coalesce(sum(${orders.total}), 0)` }).from(orders).where(and(completed, gte(orders.createdAt, startToday))),
    db.select({ total: sql<number>`coalesce(sum(${orders.total}), 0)` }).from(orders).where(and(completed, gte(orders.createdAt, startWeek))),
    db.select({ total: sql<number>`coalesce(sum(${orders.total}), 0)` }).from(orders).where(and(completed, gte(orders.createdAt, startMonth))),
    db.select({ status: orders.status, count: sql<number>`count(*)` }).from(orders).groupBy(orders.status),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(6),
    db.select({ productName: orderItems.productName, quantity: sql<number>`sum(${orderItems.quantity})`, revenue: sql<number>`sum(${orderItems.lineTotal})` }).from(orderItems).leftJoin(orders, eq(orderItems.orderId, orders.id)).where(completed).groupBy(orderItems.productName).orderBy(desc(sql`sum(${orderItems.quantity})`)).limit(4),
    db.select({ total: sql<number>`coalesce(sum(${expenses.amount}), 0)` }).from(expenses).where(gte(expenses.expenseDate, startMonth)),
  ]);
  const byStatus = Object.fromEntries(counts.map(item => [item.status, Number(item.count)]));
  return { today: Number(today[0]?.total ?? 0), week: Number(week[0]?.total ?? 0), month: Number(month[0]?.total ?? 0), orders: counts.reduce((sum, item) => sum + Number(item.count), 0), pending: byStatus.pending ?? 0, preparing: (byStatus.preparing ?? 0) + (byStatus.confirmed ?? 0), delivered: byStatus.delivered ?? 0, expenses: Number(expenseSum[0]?.total ?? 0), productLeaders: leaders.map(item => ({ ...item, quantity: Number(item.quantity), revenue: Number(item.revenue) })), recent };
}

export async function addAudit(actorUserId: number | null, action: string, entity: string, entityId: number | null, details?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values({ actorUserId, action, entity, entityId, details: details ?? null });
}
