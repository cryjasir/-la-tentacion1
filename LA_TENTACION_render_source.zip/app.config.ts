export default {
  logoUrl: "https://placehold.co/512x512/171719/E8342A.png?text=LT",
};
