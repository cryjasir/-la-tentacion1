# LA TENTACIÓN — resultados de producto

## 1. Base visual y navegación

- [x] La plataforma usa negro como color principal, rojo intenso como secundario, blanco para texto y gris oscuro para tarjetas, con apariencia elegante, moderna y profesional.
- [x] La interfaz se adapta a iPhone, Android, tabletas y computadoras; incluye navegación pública, panel propietario/empleados y cocina.
- [x] La página pública muestra el nombre LA TENTACIÓN, el eslogan EL SABOR QUE TE TIENTA, catálogo con fotografías, precios, categorías y disponibilidad.

## 2. Autenticación y permisos

- [x] El propietario puede acceder con las credenciales provisionales usuario `test1` y contraseña `test`; la contraseña se valida con hash y nunca se muestra ni se almacena en texto visible.
- [ ] El propietario tiene acceso completo y puede cambiar usuario, contraseña y correo de recuperación desde configuración.
- [x] Las sesiones usan cookie segura `webdev_app_session` compatible con Preview HTTPS y las operaciones privadas rechazan visitantes no autenticados.
- [x] La API incluye empleados con usuario/código, rol y estado, y protege las operaciones de propietario con `adminProcedure`; queda pendiente exponer toda la UI de empleados.

## 3. Catálogo y configuración de negocio

- [x] Cada producto conserva fotografía, nombre, descripción, precio, categoría, disponibilidad y estado; las categorías iniciales incluyen Hamburguesas, Yaroas, Salchipapas, Hot Dogs, Pizzas, Pollo, Picaderas, Bebidas, Combos y Especiales.
- [ ] El propietario puede crear, editar, eliminar, cambiar precios y fotos, crear categorías, promociones y combos, y marcar productos agotados. La primera UI expone disponibilidad y deja las mutaciones completas en API.
- [x] El precio aplicado queda conservado dentro del historial de cada pedido aunque el precio del catálogo cambie.
- [ ] La configuración permite editar nombre, logo, eslogan, WhatsApp, dirección, horarios, delivery, métodos de pago y notificaciones. La lectura pública y la base de configuración ya están conectadas.

## 4. Ventas y pedidos

- [x] REGISTRAR VENTA permite buscar productos, agregar cantidades y varios productos, calcular subtotal, aplicar descuento autorizado, delivery, método de pago, cliente, teléfono, observaciones y confirmar.
- [x] Cada pedido tiene identificador único, se guarda en base de datos y actualiza las métricas; la API usa clave de idempotencia y los cancelados no cuentan como ventas completadas.
- [x] La página pública permite catálogo, búsqueda, cantidades, carrito, total, nombre, teléfono, delivery/recogida, dirección, observaciones y confirmación sin iniciar sesión.
- [x] Antes de abrir WhatsApp se guarda el pedido; el mensaje preparado incluye número, productos, subtotal, delivery, total, nombre, teléfono, modalidad, dirección y observaciones; el número es configurable.
- [x] Los estados son Pendiente, Confirmado, En preparación, Listo, En camino, Entregado y Cancelado; los pedidos online aparecen en administración.

## 5. Dashboard y cocina

- [x] El panel muestra total vendido hoy, semana y mes, pedidos, ganancias estimadas, gastos, pedidos por estado, productos más vendidos y últimas ventas.
- [x] La pantalla de cocina muestra número, productos, cantidades, observaciones, hora y estado; permite marcar En preparación y Listo.
- [x] Las métricas distinguen ventas completadas de pedidos cancelados y se recalculan desde los pedidos persistidos.

## 6. Inventario, finanzas y clientes

- [ ] Inventario registra ingredientes, cantidad, unidad, entradas, salidas, mínimo, historial y alertas; las recetas pueden descontar ingredientes al confirmar una venta.
- [ ] Finanzas registra compras de ingredientes, delivery, electricidad, agua, salarios y otros gastos; diferencia ventas, ingresos, costos, gastos, ganancia bruta y neta estimada.
- [ ] Cierre de caja conserva efectivo esperado/contado, transferencias, otros pagos, total vendido, diferencias, responsable, fecha y hora.
- [ ] Clientes frecuentes conservan nombre, teléfono, historial, cantidad de compras, total comprado y última compra con acceso limitado.

## 7. Estadísticas y reportes

- [ ] Estadísticas comparan lunes a domingo ventas, pedidos, ingresos, ganancias estimadas y productos más/menos vendidos; identifican mejor día, peor día, mejor semana, mes y producto.
- [ ] Se pueden consultar hoy, ayer, últimos 7/30 días, mes actual, mes anterior, año completo y fechas personalizadas.
- [ ] Reportes diarios, semanales, mensuales, anuales, por empleado, inventario, gastos, ganancias y cierres se pueden descargar en PDF y Excel.
- [ ] Las anulaciones y modificaciones quedan en auditoría; las ventas no se eliminan silenciosamente.

## 8. Persistencia y entrega

- [x] La información usa backend y base de datos persistente, sobrevive al cierre de la página y puede consultarse desde otro dispositivo.
- [x] La aplicación incluye validación de datos, control de sesiones, registro de actividad, protección contra pedidos duplicados y base preparada para copias de seguridad.
- [x] El proyecto pasa diagnósticos TypeScript, build de producción y validación de rutas; queda pendiente el checkpoint/publicación final.
