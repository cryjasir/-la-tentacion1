# LA TENTACIÓN fuera de Manus

## Tecnología y comandos

El proyecto usa **React 19 + Vite + TypeScript** para la interfaz, **Express** para el servidor HTTP, **tRPC** para la API tipada, **Drizzle ORM** para acceso a datos y **MySQL/MariaDB** como base de datos. El gestor fijado es **pnpm 10.18.0** mediante `packageManager` y `corepack`.

```bash
corepack enable
pnpm install --frozen-lockfile
pnpm check
pnpm build
pnpm start
```

Para desarrollo:

```bash
pnpm dev
```

El servidor escucha en `0.0.0.0` y usa `PORT`, con valor local predeterminado `3000`. La comprobación de salud es `GET /api/health`.

## Variables de entorno

Configura estas variables en Render o en un archivo local no versionado:

- `DATABASE_URL`: obligatoria. URL de conexión MySQL/MariaDB compatible.
- `MANUS_JWT_SECRET`: obligatoria para firmar y verificar las sesiones del login local. Debe ser un secreto largo y aleatorio.
- `MANUS_PROJECT_ID`: obligatoria para identificar la aplicación dentro del payload de sesión. Puede ser un identificador estable elegido para el despliegue externo.
- `NODE_ENV=production`: recomendada en Render.
- `PORT`: Render la inyecta automáticamente; no es necesario fijarla allí.
- `MANUS_OAUTH_API_URL`, `MANUS_API_URL`, `MANUS_API_KEY` y `OWNER_OPEN_ID`: opcionales y solo necesarias si se reactivan integraciones Manus/OAuth.

Los nombres están documentados en `.env.example`. Nunca subas un `.env` real ni escribas contraseñas en este repositorio.

## Base de datos y conservación de pedidos

La aplicación usa Drizzle con dialecto MySQL. `DATABASE_URL` apunta a una base externa persistente; el contenedor no debe ser la fuente de almacenamiento. Las tablas principales son usuarios, categorías, productos, pedidos, partidas de pedido, gastos, inventario, movimientos, cierres de caja, configuración y auditoría.

Las migraciones versionadas están en `drizzle/`. En un entorno nuevo, configura primero `DATABASE_URL` y ejecuta una vez:

```bash
pnpm db:migrate
```

`pnpm db:push` genera y aplica cambios de esquema; úsalo solo durante desarrollo controlado. Los pedidos y registros se conservan mientras la base MySQL/MariaDB contratada mantenga sus datos y copias de seguridad. Antes de migrar producción, realiza un dump de la base y conserva el archivo fuera del repositorio.

La aplicación ejecuta semillas iniciales idempotentes para categorías, productos, inventario, configuración y el propietario provisional cuando corresponde. No borres la base de datos al redeployar el servicio.

## Despliegue en Render con Docker

1. Crea una base MySQL/MariaDB externa compatible y copia su URL de conexión.
2. Sube este proyecto a un repositorio Git propio o carga el ZIP como copia de trabajo.
3. En Render crea un **Web Service** desde el repositorio y selecciona **Docker**; el `Dockerfile` ya instala pnpm, instala dependencias congeladas, compila y ejecuta `dist/index.js`.
4. Configura `DATABASE_URL`, `MANUS_JWT_SECRET` y `MANUS_PROJECT_ID` como variables protegidas. Puedes usar el `render.yaml` como Blueprint; `DATABASE_URL` queda marcada para introducirla manualmente y Render genera los secretos JWT/ID.
5. Usa `/api/health` como health check. Render debe proporcionar `PORT`; el servidor ya escucha en ese puerto.
6. Después del primer despliegue, verifica `/api/health`, abre el menú público y prueba el login local. Ejecuta las migraciones contra la base elegida antes de recibir pedidos reales.

## Qué contiene la copia

El ZIP incluye código frontend, backend, API tRPC, esquema y migraciones Drizzle, configuración TypeScript/Vite/Tailwind, `package.json`, `pnpm-lock.yaml`, Dockerfile, Blueprint de Render, plantilla de variables y esta guía. Se excluyen `node_modules`, `dist`, `.git`, logs y secretos locales porque son artefactos regenerables o información sensible.

## Importante sobre el login

El flujo implementado usa login local con sesiones JWT firmadas por `MANUS_JWT_SECRET`; OAuth de Manus es opcional y no debe configurarse si el despliegue será completamente independiente. Cambia las credenciales provisionales del propietario desde una futura pantalla de configuración antes de operar en producción y conserva `MANUS_JWT_SECRET` estable entre redeploys para no invalidar sesiones existentes.
