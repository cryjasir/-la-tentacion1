# Plan de implementación — LA TENTACIÓN

## Alcance aprobado

LA TENTACIÓN será una plataforma web profesional para operar un restaurante: página pública de pedidos, panel privado del propietario y empleados, cocina, ventas, catálogo, pedidos, inventario, finanzas, clientes, estadísticas, caja, reportes y configuración. La primera entrega implementará la base persistente y los flujos más críticos de operación sin sustituirlos por una maqueta: autenticación local segura para propietario/empleados, catálogo administrable, pedidos públicos guardados en base de datos, ventas manuales, dashboard operativo, estados de pedido y pantalla de cocina. Los módulos de inventario, gastos, cierres, clientes, promociones y reportes se dejarán conectados al mismo modelo de datos y se ampliarán sobre esta base.

## Implementación

- **Frontend:** React + TypeScript + Wouter + Tailwind, con un shell visual compartido para página pública, administración y cocina. La página pública usa carrito local para la sesión del cliente, pero el pedido confirmado siempre se persiste mediante tRPC antes de abrir WhatsApp.
- **Backend:** Express + tRPC. Las operaciones públicas son catálogo y creación de pedidos; las operaciones privadas exigen sesión `webdev_app_session` y validan rol. La sesión se firma con el mecanismo JWT del starter y las contraseñas se almacenan como hash scrypt con sal, nunca en texto visible.
- **Persistencia:** Drizzle sobre MySQL administrado. Se amplía el usuario para cuentas locales y se agregan productos, categorías, pedidos, partidas, configuración, inventario, gastos, cierres y auditoría. Los importes se almacenan como enteros en pesos dominicanos para evitar errores de redondeo y se conserva el precio aplicado en cada partida del pedido.
- **Flujos críticos:** crear pedido online con número único y estado Pendiente; registrar venta manual; cambiar estados desde administración/cocina; consultar métricas agregadas; gestionar disponibilidad y precio de productos; generar enlace `wa.me` con el pedido ya guardado.
- **Preparación para crecer:** procedimientos de servidor separados por dominio, esquema aditivo, auditoría para cambios de estado, rutas declaradas en `public/manus-routes.json`, y configuración de negocio editable sin tocar código.

## Estructura principal

- `client/src/pages/`: `PublicMenu`, `Login`, `Dashboard`, `Kitchen` y páginas auxiliares.
- `client/src/components/`: shell de administración, tarjetas de métricas, modal de carrito y componentes UI reutilizables.
- `server/routers.ts`: procedimientos de autenticación, catálogo, pedidos, dashboard, cocina y configuración.
- `server/db.ts`: acceso tipado a usuarios, productos, pedidos y agregados.
- `drizzle/schema.ts` y `drizzle/`: tablas y migraciones persistentes.
- `public/manus-routes.json`: manifiesto de rutas navegables.

## Dirección visual

### Alternativas consideradas

- **Brutalismo culinario premium** — 0.06: negro carbón, rojo salsa y tipografía contundente, con tarjetas que parecen comandas de cocina.
- **Editorial nocturna** — 0.04: composición asimétrica, alto contraste y acentos rojos como neón gastronómico.
- **Minimalismo de cadena rápida** — 0.08: blanco dominante, rojo corporativo y componentes utilitarios.

### Elección: Brutalismo culinario premium

- **Movimiento:** brutalismo editorial aplicado a un software de restaurante, con contraste de comandas, números grandes y superficies oscuras.
- **Principios:** claridad en segundos, jerarquía por color, densidad operativa sin ruido y momentos de apetito en la vista pública.
- **Color:** carbón `#0D0D0F` como cocina nocturna; rojo propio `#E8342A` como salsa y señal de acción; crema `#F5F0E8` para equilibrar el negro y marfil para lectura prolongada.
- **Layout:** navegación lateral compacta en administración, tablero de métricas en columnas quebradas y una franja de “pedido actual” que funciona como comanda viva; en público, menú editorial con categorías horizontales y carrito fijo.
- **Firma visual:** numeración monoespaciada para pedidos, chips de estado tipo etiqueta de cocina y líneas diagonales sutiles inspiradas en papel de envoltura.
- **Interacción:** las acciones primarias deben sentirse inmediatas y confirmadas; cada mutación muestra feedback visible, la disponibilidad se expresa con color y ningún cambio crítico se oculta tras una animación.
- **Animación:** entrada suave de 180–240 ms, desplazamiento corto, `prefers-reduced-motion` respetado; los pedidos nuevos pueden usar un pulso breve en rojo, nunca loops intensos.
- **Tipografía:** `Space Grotesk` para titulares y métricas; `DM Sans` para UI y formularios; `IBM Plex Mono` para folios, horas y totales.
- **Esencia:** el centro de mando para vender más y cocinar mejor, pensado para restaurantes que necesitan velocidad y control. Personalidad: preciso, intenso, hospitalario.
- **Voz:** titulares directos y apetitosos; CTAs como “Abrir comanda”, “Enviar a cocina” y “Ver lo que está vendiendo”. Ejemplos: “Lo que sale hoy, bajo control.” / “Tu próximo antojo empieza aquí.”
- **Wordmark:** “LA” pequeño sobre “TENTACIÓN” en mayúsculas, con la tilde convertida en una llama geométrica roja.
- **Color de marca:** rojo salsa `#E8342A`.

## Build y entrega

Se usará `pnpm dev` en el puerto gestionado 3000, `pnpm check`, la migración de Drizzle y el build de producción. Después de validar el preview, se guardará un checkpoint en `main`; la publicación se hará cuando el resultado funcional esté listo y la plataforma devuelva confirmación explícita.